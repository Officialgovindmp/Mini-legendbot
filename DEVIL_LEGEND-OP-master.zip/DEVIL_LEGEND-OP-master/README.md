# LEGENDBOT
HERE IS ALL THE PLUGIN OF LEGENDBOT

## Deploy 
- Click Here :- [main repo](https://github.com/Tecosys/LEGENDBOT)
- Fork The Main Repo 
- Go to Setting Of Repo 
- Rename the Fork Repo Put Anything Example : LEGEND1BOT, HSKSBOT, LEGENDOFFBOT etc...
- Now U Can Deploy This Bot

## Repl
- Click Here - [REPL](https://replit.com/@KrishnaJaiswal1/LEGENDBOT#main.py)

