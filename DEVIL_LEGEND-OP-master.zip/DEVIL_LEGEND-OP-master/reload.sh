#!/bin/bash

python3 -m Legendbot
