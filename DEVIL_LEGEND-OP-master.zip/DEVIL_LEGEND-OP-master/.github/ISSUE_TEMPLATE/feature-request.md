---
name: Feature Request
about: Suggest ideas, changes or other enhancements in the code
title: ''
labels: enhancement
assignees: ''

---

Please describe your idea. Would you like another friendly method? Renaming them to something more appropriated? Changing the way something works?
