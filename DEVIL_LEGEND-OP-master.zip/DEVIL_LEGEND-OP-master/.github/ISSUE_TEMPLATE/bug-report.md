---
name: Bug Report
about: Create a report about a bug inside the library or issues with the documentation
title: ''
labels: ''
assignees: ''

---

**Checklist**
* [ ] The error is in the code
* [ ] The Error in cmd

**Code that causes the issue**
```
Command Name :
Base Folder Name :
```

**Traceback**
```
Traceback (most recent call last):
  File "code.py", line 1, in <code>

```
